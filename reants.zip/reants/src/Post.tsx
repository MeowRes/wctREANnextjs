import React, { useEffect } from 'react';
import { SvelteHeart } from 'svelte-heart'
// Define the props interface
interface UserProfileProps {
    name: string;
    username: string;
    profileImage: string;
    content: string;
    contentImage: string;
}

const Post: React.FC<UserProfileProps> = ({
    name,
    username,
    profileImage,
    content,
    contentImage,
}) => {
    useEffect(() => {
        // Any initialization logic if needed
    }, []);

    const [liked, setLiked] = React.useState(false);
    const [bookmarked, setBookmarked] = React.useState(false);

    const likeEvent = () => { //this is where you set up an ajax call.
        setLiked(prev => !prev);
    }
    const bookmarkEvent = () => { //this is where you set up an ajax call.
        setBookmarked(prev => !prev);
    }


    return (

        <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', maxWidth: '550px', backgroundColor: '#DCE0ED', padding: '30px' }}>
            <style>
                {`
                    .post-container {
                        display: flex;
                        flex-direction: row;
                        align-items: center;
                        max-width: 550px;
                        padding: 10px;
                    }
                    .profile-image {
                        margin-right: 50px;
                        margin-bottom: 100px;
                    }
                    .icon-container {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        margin-right: 10px;
                    }
                    .like-icon, .save-icon {
                        cursor: pointer;
                        font-size: 24px;
                    }
                    .liked {
                        color: purple;
                    }
                    .not-liked {
                        color: gray;
                    }
                    .saved {
                        color: purple;
                    }
                    .not-saved {
                        color: gray;
                    }
                    .content {
                        flex: 1;
                    }
                    .tag {
                        margin-bottom: 10px;
                    }
                    .post-content {
                        display: flex;
                        align-items: center;
                    }
                    .post-text {
                        margin-right: 10px;
                        padding: 10px;
                        background-color: #000000;
                        flex: 1;
                        height: 200px;
                        width: 200px;

                    }
                    .post-image {
                        width: 200px;
                        height: 200px;
                    }
                `}
            </style>
            <div style={{ marginRight: '60px' }}>
                <img src={profileImage} alt={`${name}'s profile`} style={{ width: '45px', borderRadius: '50%', marginBottom: '230px', marginLeft: '10px', marginRight: '10px' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginLeft: '-110px', marginRight: '40px', marginTop: '25px' }}>
                <span onClick={likeEvent} style={{ fontSize: '25px' }}>
                    {liked ? '\u{1F49C}' : '\u{1F90D}'} {/* Heart icon that changes color based on liked status */}
                </span>
                <span onClick={bookmarkEvent} style={{ fontSize: '28px', marginTop: '25px' }}>
                    {bookmarked ? '\u{2611}' : '\u{2714}'}
                </span></div>
            <div style={{ flex: 1 }}>

                <div style={{ marginBottom: '5px' }}>
                    <p style={{ margin: 0 }}>{name}</p>
                    <p style={{ margin: 0 }}>@{username}</p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <p style={{ marginRight: '10px', padding: '10px', backgroundColor: '#ebedf4', height: '180px', width: '220px', }}>
                        {content.length > 150 ? content.slice(0, 150) + '...' : content}
                    </p>
                    <img src={contentImage} alt="Post content" />
                </div>
            </div>
        </div>
    );
};

export default Post;
