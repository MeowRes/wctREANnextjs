
import React, { useState } from 'react';
import './App.css';
import Post from './Post';

const App: React.FC = () => {
  // State to manage the current view
  const [currentView, setCurrentView] = useState<'home' | 'create' | 'senior' | 'chat' | 'community' | 'setting'>('home');

  // Handlers for buttons
  const create = () => {
    setCurrentView('create');
  };

  const home = () => {
    setCurrentView('home');
  };

  const senior = () => {
    setCurrentView('senior');
  };

  const community = () => {
    setCurrentView('community');
  };

  const chat = () => {
    setCurrentView('chat');
  };

  const setting = () => {
    setCurrentView('setting');
  };

  return (
    <div className='container'>
      <style>
        {`
          .container {
            display: flex;
            background-color: #DCE0ED ;
        
          }
          .left {
            width: 300px;
            background-color: #bbc5dd;
            padding: 20px 0 0 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: fixed;
            height:100%;
          }
          .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 110px;
            margin-right: 20px;
          }
          .pf {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            
          }
          .pf img {
            border-radius: 50%;
            margin-right: 10px;
          }
          nav {
            display: flex;
            flex-direction: column;
            width: 100%;
            list-style: none;
            padding: 0;
          }
          
          button {
            cursor: pointer;
            font-size: 16px;
            border: none;
            background-color: #bbc5dd;
            color: black;

            width: 100%; 
            height:80px;
            transition: background-color 0.2s;
            
          }
          button:hover{
            background-color: #DCE0ED;
          }
          .right {
            flex: 1;
            padding: 20px;
            overflow-y: auto; /* Allows scrolling if content exceeds height */
            margin-left:400px;
          
          }
          .post {
            max-width: 550px;
            margin: auto;
          }
          .top .user{
          margin-top: -15px;
          }
        `}
      </style>

      <div className='left'>
        <div className='top'> 
            <div className='pf'>
              <img src="https://via.placeholder.com/50"/>
              <label className='logo'>LOGO</label>
            </div>
            <p>name</p>
            <p className='user'>user</p>
        </div>
        <nav>
          
          <li><button className="index" onClick={home}>Home</button></li>
          <li><button className="senior" onClick={senior}>Our Seniors</button></li>
          <li><button className="chat" onClick={chat}>Chat</button></li>
          <li><button className="community" onClick={community}>Community</button></li>
          <li><button className="setting" onClick={setting}>Settings</button></li>
        </nav>
      </div>


      <div className='right'>
        {currentView === 'home' && (
          <>
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            <Post
              name="John Doe"
              username="johndoe"
              profileImage="https://via.placeholder.com/50"
              content="This is a sample post content that showcases how to use a React component with TypeScript."
              contentImage="https://via.placeholder.com/200"
            />
            
          </>

        )}

        {currentView === 'create' && <div>Create Component</div>}
        {currentView === 'senior' && <div>Our Seniors Component</div>}
        {currentView === 'chat' && <div>Chat Component</div>}
        {currentView === 'community' && <div>Community Component</div>}
        {currentView === 'setting' && <div>Settings Component</div>}
      </div>
    </div>
  );
};

export default App;
